import UIKit

/*
var greeting = "Hello, playground"
print (greeting)

let score = 85
if score >= 90 {
    print ("You pass")
        }


var scores = [50, 60, 90, 70]
scores.append(80)
print(scores)

if scores.count > 4
{
    scores.remove(at: 0)
}
print (scores  )

var username = ""

if username.isEmpty{
    username = "anonymous"
}
    
print("welcome, \(username)")

//////////////////////////////////////

let age = 18

if age >= 18 {
    print("You are of age")
}
    else
    {
        print("You are to young")
    }

let temp = 80

//&& and
//|| or
if temp >= 80 || temp <= 90{
    print("Its pretyy hot!")
}
 
 
/////////////////////////////////////////////////////


enum forcast {
    case sun , rain, snow, windy
}

let weather = forcast.snow

switch weather {
case .sun:
    print("Its sunny")
    //fallthrough ----used to continue the case statement
case .rain:
    print("It's rainy")
default :
    print("Harsh weather!")
}

*/
//ternary check, quick check
let age = 17

let canVote = age >= 18 ? "Yes" : "No"
print(canVote)
  
